import React from "react";
import Menu from "../menu";

const Header = () =>  <header id="header"><Menu/></header>;
export default Header;
