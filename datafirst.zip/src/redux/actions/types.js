export const SAVE_MENU = "SAVE_MENU";
export const SAVE_INFO = "SAVE_INFO";
export const DAY_NAME = "DAY_NAME";




