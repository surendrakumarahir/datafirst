export const defaultOptions = {
	baseUrl: "https://dh-dev-apim.azure-api.net",
	apikey: "c5f67862202f4577ab36a72ad04b38ca"
};
