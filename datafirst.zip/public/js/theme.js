$(function () {

	// if($(".owl-carousel").length > 0)
	// {
	// 	$('#recent_properties_carousel').owlCarousel({
	// 		items:4,
	// 		margin:30,
	// 		nav:false,
	// 		dots:true,
	// 		responsive:{
	// 			0:{
	// 				items:1
	// 			},
	// 			640:{
	// 				items:2
	// 			},
	// 			1024:{
	// 				items:3,
	// 			},
	// 			1200:{
	// 				items:4,
	// 			},
	// 		}
	// 	});
		
	// 	$('#investment_deals_carousel').owlCarousel({
	// 		items:3,
	// 		margin:30,
	// 		nav:false,
	// 		dots:true,
	// 		responsive:{
	// 			0:{
	// 				items:1
	// 			},
	// 			640:{
	// 				items:2
	// 			},
	// 			1024:{
	// 				items:3,
	// 			},
	// 			1200:{
	// 				items:3,
	// 			},
	// 		}
	// 	});

	
	// 	$(".owl-carousel").owlCarousel({
	// 		items:1,
	// 		margin:30,
	// 		nav:false,
	// 		dots:true
	// 	});
	// }
});