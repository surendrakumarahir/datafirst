$(function () {
    $('[data-fancybox="property-detail-hero-gallery"]').fancybox({
        animationEffect: "fade",
        animationDuration: 600,

        transitionEffect: "slide",
        transitionDuration: 600,

        thumbs: {
            axis: "y",
        },
    });
});